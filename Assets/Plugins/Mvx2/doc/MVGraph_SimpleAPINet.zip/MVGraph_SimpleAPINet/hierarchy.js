var hierarchy =
[
    [ "MVGraphAPI.Col", "struct_m_v_graph_a_p_i_1_1_col.html", null ],
    [ "MVGraphAPI.FrameAudioExtractor", "class_m_v_graph_a_p_i_1_1_frame_audio_extractor.html", null ],
    [ "MVGraphAPI.FrameMeshExtractor", "class_m_v_graph_a_p_i_1_1_frame_mesh_extractor.html", null ],
    [ "MVGraphAPI.FrameMiscDataExtractor", "class_m_v_graph_a_p_i_1_1_frame_misc_data_extractor.html", null ],
    [ "MVGraphAPI.FrameTextureExtractor", "class_m_v_graph_a_p_i_1_1_frame_texture_extractor.html", null ],
    [ "GraphNode", null, [
      [ "MVGraphAPI.AutoCompressorGraphNode", "class_m_v_graph_a_p_i_1_1_auto_compressor_graph_node.html", null ],
      [ "MVGraphAPI.AutoDecompressorGraphNode", "class_m_v_graph_a_p_i_1_1_auto_decompressor_graph_node.html", null ],
      [ "MVGraphAPI.InjectFileDataGraphNode", "class_m_v_graph_a_p_i_1_1_inject_file_data_graph_node.html", null ],
      [ "MVGraphAPI.InjectMemoryDataGraphNode", "class_m_v_graph_a_p_i_1_1_inject_memory_data_graph_node.html", null ],
      [ "MVGraphAPI.Mvx2FileReaderGraphNode", "class_m_v_graph_a_p_i_1_1_mvx2_file_reader_graph_node.html", null ],
      [ "MVGraphAPI.Mvx2FileWriterGraphNode", "class_m_v_graph_a_p_i_1_1_mvx2_file_writer_graph_node.html", null ],
      [ "MVGraphAPI.NetworkReceiverGraphNode", "class_m_v_graph_a_p_i_1_1_network_receiver_graph_node.html", null ],
      [ "MVGraphAPI.NetworkTransmitterGraphNode", "class_m_v_graph_a_p_i_1_1_network_transmitter_graph_node.html", null ]
    ] ],
    [ "MVGraphAPI.Mvx2FileAsyncReader", "class_m_v_graph_a_p_i_1_1_mvx2_file_async_reader.html", null ],
    [ "MVGraphAPI.Mvx2FileRandomAccessReader", "class_m_v_graph_a_p_i_1_1_mvx2_file_random_access_reader.html", null ],
    [ "MVGraphAPI.Mvx2FileSyncReader", "class_m_v_graph_a_p_i_1_1_mvx2_file_sync_reader.html", null ],
    [ "NativeObjectHolder", null, [
      [ "MVGraphAPI.MeshData", "class_m_v_graph_a_p_i_1_1_mesh_data.html", null ],
      [ "MVGraphAPI.MeshSplitter", "class_m_v_graph_a_p_i_1_1_mesh_splitter.html", null ],
      [ "MVGraphAPI.Mvx2FileSimpleDataInfo", "class_m_v_graph_a_p_i_1_1_mvx2_file_simple_data_info.html", null ]
    ] ],
    [ "MVGraphAPI.SimpleDataLayersGuids", "class_m_v_graph_a_p_i_1_1_simple_data_layers_guids.html", null ],
    [ "MVGraphAPI.Vec2", "struct_m_v_graph_a_p_i_1_1_vec2.html", null ],
    [ "MVGraphAPI.Vec3", "struct_m_v_graph_a_p_i_1_1_vec3.html", null ]
];