var searchData=
[
  ['r',['r',['../struct_m_v_graph_a_p_i_1_1_col.html#a6fd8f63924c97891c4bd692655b194e3',1,'MVGraphAPI::Col']]]
];
