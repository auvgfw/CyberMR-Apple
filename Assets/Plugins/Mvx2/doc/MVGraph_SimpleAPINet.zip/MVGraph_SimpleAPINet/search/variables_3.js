var searchData=
[
  ['g',['g',['../struct_m_v_graph_a_p_i_1_1_col.html#a15ab9d29f594f8f3f226894f46cdadd2',1,'MVGraphAPI::Col']]]
];
