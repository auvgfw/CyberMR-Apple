var searchData=
[
  ['destroynativeobject',['DestroyNativeObject',['../class_m_v_graph_a_p_i_1_1_mesh_data.html#a5a5acb2a2a6f212b38873fb74315c98f',1,'MVGraphAPI.MeshData.DestroyNativeObject()'],['../class_m_v_graph_a_p_i_1_1_mesh_splitter.html#a73e3f92d9442d7b539b8a23c12517701',1,'MVGraphAPI.MeshSplitter.DestroyNativeObject()'],['../class_m_v_graph_a_p_i_1_1_mvx2_file_simple_data_info.html#ade939b645b56dbb2cf1576e62c824f48',1,'MVGraphAPI.Mvx2FileSimpleDataInfo.DestroyNativeObject()']]]
];
