var searchData=
[
  ['segment_5finfo_5fdata_5flayer',['SEGMENT_INFO_DATA_LAYER',['../class_m_v_graph_a_p_i_1_1_simple_data_layers_guids.html#a639b417cd35265bdf47ef0884f44c092',1,'MVGraphAPI::SimpleDataLayersGuids']]]
];
