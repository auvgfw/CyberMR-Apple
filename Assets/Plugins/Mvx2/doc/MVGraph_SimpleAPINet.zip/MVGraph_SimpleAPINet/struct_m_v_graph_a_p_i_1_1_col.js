var struct_m_v_graph_a_p_i_1_1_col =
[
    [ "a", "struct_m_v_graph_a_p_i_1_1_col.html#af1816bd76330a1e151094854d7f7ed9c", null ],
    [ "b", "struct_m_v_graph_a_p_i_1_1_col.html#ac365a4382a89dc7aee1d7ac812d683f5", null ],
    [ "g", "struct_m_v_graph_a_p_i_1_1_col.html#a15ab9d29f594f8f3f226894f46cdadd2", null ],
    [ "r", "struct_m_v_graph_a_p_i_1_1_col.html#a6fd8f63924c97891c4bd692655b194e3", null ]
];