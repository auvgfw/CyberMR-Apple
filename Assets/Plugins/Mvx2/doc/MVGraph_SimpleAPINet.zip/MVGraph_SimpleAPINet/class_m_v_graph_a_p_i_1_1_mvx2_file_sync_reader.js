var class_m_v_graph_a_p_i_1_1_mvx2_file_sync_reader =
[
    [ "Mvx2FileSyncReader", "class_m_v_graph_a_p_i_1_1_mvx2_file_sync_reader.html#abd8f7f8c9c2e024d54d0bcc239995f1b", null ],
    [ "ReadNextFrame", "class_m_v_graph_a_p_i_1_1_mvx2_file_sync_reader.html#afd7ddb8ba5643dffb59f781d4bd84dda", null ]
];