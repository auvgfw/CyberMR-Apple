var class_m_v_graph_a_p_i_1_1_block_graph_node =
[
    [ "FullBehaviour", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a18b2bd77713245c1e3c67b03fbfab4ed", [
      [ "FB_DROP_FRAMES", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a18b2bd77713245c1e3c67b03fbfab4eda3d091b60ab17883ed1620c696a7e15c1", null ],
      [ "FB_BLOCK_FRAMES", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a18b2bd77713245c1e3c67b03fbfab4eda53a461dc26ff5b067ed7927758b0c00b", null ]
    ] ],
    [ "GetDroppedFramesCount", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a1633ea736e96da324693a4501b6d8536", null ],
    [ "ResetDroppedFramesCounter", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a363ff4f4d2932abfe4267f72f813d3e6", null ],
    [ "SetFullBehaviour", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#aa6716420287d7c5d7f320c639a6300cd", null ]
];