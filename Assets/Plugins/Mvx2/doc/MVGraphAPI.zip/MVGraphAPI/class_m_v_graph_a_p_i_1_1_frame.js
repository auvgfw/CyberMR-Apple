var class_m_v_graph_a_p_i_1_1_frame =
[
    [ "Frame", "class_m_v_graph_a_p_i_1_1_frame.html#ae7cc2b696151beceb63813ffcc81df61", null ],
    [ "~Frame", "class_m_v_graph_a_p_i_1_1_frame.html#a015f307f224f7d5239267bafa49f4062", null ],
    [ "ActivateStreamWithIndex", "class_m_v_graph_a_p_i_1_1_frame.html#a86be9acdb6778e89c436f0a60e65fcae", null ],
    [ "GetActiveStream", "class_m_v_graph_a_p_i_1_1_frame.html#a417970c061e18ebb285719f888df95e2", null ],
    [ "GetActiveStreamIndex", "class_m_v_graph_a_p_i_1_1_frame.html#a5bc95983352e2f103fcd5fe2aeaf0ff3", null ],
    [ "GetNumStreams", "class_m_v_graph_a_p_i_1_1_frame.html#a891fb7d8e2ee75daf275cdaa5bcc5a20", null ],
    [ "GetStreamAtomNr", "class_m_v_graph_a_p_i_1_1_frame.html#adfb60ad7e2fb86bc0211f7745565355f", null ],
    [ "GetStreamAtomTimestamp", "class_m_v_graph_a_p_i_1_1_frame.html#a43a687fcdff29f5ec09e8010a2fc42f7", null ],
    [ "GetStreamId", "class_m_v_graph_a_p_i_1_1_frame.html#a48eb3411aa1023d94717a8737a01655e", null ],
    [ "GetStreams", "class_m_v_graph_a_p_i_1_1_frame.html#ac6001b3ac0eb08d483bdd942beaafe47", null ],
    [ "StreamContainsDataLayer", "class_m_v_graph_a_p_i_1_1_frame.html#aca15a2063f64fb4cd2686578e2214b1b", null ]
];