var class_m_v_graph_a_p_i_1_1_i_frame_listener =
[
    [ "~IFrameListener", "class_m_v_graph_a_p_i_1_1_i_frame_listener.html#a91830f4bd8b26237e353775cf6e30160", null ],
    [ "OnFrameProcessed", "class_m_v_graph_a_p_i_1_1_i_frame_listener.html#add634fd048c79dc857fc4b785749fd03", null ]
];