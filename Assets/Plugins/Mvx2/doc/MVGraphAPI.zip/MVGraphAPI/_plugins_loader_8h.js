var _plugins_loader_8h =
[
    [ "LoadPlugin", "_plugins_loader_8h.html#a4045fd5e492e1adef07f5dbf6e978a74", null ],
    [ "LoadPluginsInFolder", "_plugins_loader_8h.html#a420edd5208b75cdd84fd711059983f76", null ]
];