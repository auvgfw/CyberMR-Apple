var searchData=
[
  ['loadplugin',['LoadPlugin',['../_plugins_loader_8h.html#a4045fd5e492e1adef07f5dbf6e978a74',1,'MVGraphAPI::PluginsLoader']]],
  ['loadpluginsinfolder',['LoadPluginsInFolder',['../_plugins_loader_8h.html#a420edd5208b75cdd84fd711059983f76',1,'MVGraphAPI::PluginsLoader']]]
];
