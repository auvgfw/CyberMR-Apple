var searchData=
[
  ['pluginsloader_2eh',['PluginsLoader.h',['../_plugins_loader_8h.html',1,'']]]
];
