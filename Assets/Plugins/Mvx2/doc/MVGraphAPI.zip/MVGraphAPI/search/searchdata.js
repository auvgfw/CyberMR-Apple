var indexSectionsWithContent =
{
  0: "abcfgilmoprstu~",
  1: "abfgimrs",
  2: "fpru",
  3: "abcfglmoprstu~",
  4: "f",
  5: "fr",
  6: "fr",
  7: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

