var _utils_8h =
[
    [ "GetAppExeDirectory", "_utils_8h.html#ab11463310bde417df5dcf9c30f91abdd", null ],
    [ "GetAppExeFilePath", "_utils_8h.html#a06f5e1b8642950178c9ce11ec085e672", null ],
    [ "GetMVXGuidAliasDatabase", "_utils_8h.html#ac080a2ecb06b6becb20b70178aa77b05", null ],
    [ "GetMVXLoggerInstance", "_utils_8h.html#adba8d94d01517132d7a4373d65947d1c", null ],
    [ "ResetMVXLoggerInstance", "_utils_8h.html#a7bde5edb005db0da6e9624bc0b3e0a6d", null ],
    [ "SetMVXLoggerInstance", "_utils_8h.html#ac57d9669b71d01a6f44efd9be66f8ad5", null ]
];