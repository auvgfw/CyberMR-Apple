var class_m_v_graph_a_p_i_1_1_frame_access_graph_node =
[
    [ "FrameAccessGraphNode", "class_m_v_graph_a_p_i_1_1_frame_access_graph_node.html#a9d834b40f8e654d7a592059cb18c2032", null ],
    [ "~FrameAccessGraphNode", "class_m_v_graph_a_p_i_1_1_frame_access_graph_node.html#ab0b9493522ca9d53c1a3df79597adfd4", null ],
    [ "GetRecentProcessedFrame", "class_m_v_graph_a_p_i_1_1_frame_access_graph_node.html#ad3e98b34c855b2af157cf938c10c3101", null ]
];