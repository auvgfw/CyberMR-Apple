var hierarchy =
[
    [ "MVGraphAPI::AtomList", "class_m_v_graph_a_p_i_1_1_atom_list.html", null ],
    [ "MVGraphAPI::FilterList", "class_m_v_graph_a_p_i_1_1_filter_list.html", null ],
    [ "NonAssignable", null, [
      [ "MVGraphAPI::Frame", "class_m_v_graph_a_p_i_1_1_frame.html", null ],
      [ "MVGraphAPI::Graph", "class_m_v_graph_a_p_i_1_1_graph.html", null ],
      [ "MVGraphAPI::GraphBuilder", "class_m_v_graph_a_p_i_1_1_graph_builder.html", [
        [ "MVGraphAPI::ManualGraphBuilder", "class_m_v_graph_a_p_i_1_1_manual_graph_builder.html", null ]
      ] ],
      [ "MVGraphAPI::GraphNode", "class_m_v_graph_a_p_i_1_1_graph_node.html", [
        [ "MVGraphAPI::BlockGraphNode", "class_m_v_graph_a_p_i_1_1_block_graph_node.html", [
          [ "MVGraphAPI::BlockFPSGraphNode", "class_m_v_graph_a_p_i_1_1_block_f_p_s_graph_node.html", null ],
          [ "MVGraphAPI::BlockManualGraphNode", "class_m_v_graph_a_p_i_1_1_block_manual_graph_node.html", null ]
        ] ],
        [ "MVGraphAPI::ManualLiveFrameSourceGraphNode", "class_m_v_graph_a_p_i_1_1_manual_live_frame_source_graph_node.html", null ],
        [ "MVGraphAPI::ManualOfflineFrameSourceGraphNode", "class_m_v_graph_a_p_i_1_1_manual_offline_frame_source_graph_node.html", null ],
        [ "MVGraphAPI::SingleFilterGraphNode", "class_m_v_graph_a_p_i_1_1_single_filter_graph_node.html", [
          [ "MVGraphAPI::AsyncFrameAccessGraphNode", "class_m_v_graph_a_p_i_1_1_async_frame_access_graph_node.html", null ],
          [ "MVGraphAPI::FrameAccessGraphNode", "class_m_v_graph_a_p_i_1_1_frame_access_graph_node.html", null ]
        ] ]
      ] ],
      [ "MVGraphAPI::GraphRunner", "class_m_v_graph_a_p_i_1_1_graph_runner.html", [
        [ "MVGraphAPI::AutoSequentialGraphRunner", "class_m_v_graph_a_p_i_1_1_auto_sequential_graph_runner.html", null ],
        [ "MVGraphAPI::ManualSequentialGraphRunner", "class_m_v_graph_a_p_i_1_1_manual_sequential_graph_runner.html", null ],
        [ "MVGraphAPI::RandomAccessGraphRunner", "class_m_v_graph_a_p_i_1_1_random_access_graph_runner.html", null ]
      ] ],
      [ "MVGraphAPI::IFrameListener", "class_m_v_graph_a_p_i_1_1_i_frame_listener.html", null ],
      [ "MVGraphAPI::IParameterValueChangedListener", "class_m_v_graph_a_p_i_1_1_i_parameter_value_changed_listener.html", null ],
      [ "MVGraphAPI::SourceInfo", "class_m_v_graph_a_p_i_1_1_source_info.html", null ]
    ] ],
    [ "MVGraphAPI::SharedAtomPtr", "class_m_v_graph_a_p_i_1_1_shared_atom_ptr.html", null ],
    [ "MVGraphAPI::SharedFilterPtr", "class_m_v_graph_a_p_i_1_1_shared_filter_ptr.html", null ]
];