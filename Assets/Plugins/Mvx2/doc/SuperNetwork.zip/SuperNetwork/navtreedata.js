var NAVTREE =
[
  [ "SuperNetwork", "index.html", [
    [ "Mantis Vision: SuperNetwork", "index.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';