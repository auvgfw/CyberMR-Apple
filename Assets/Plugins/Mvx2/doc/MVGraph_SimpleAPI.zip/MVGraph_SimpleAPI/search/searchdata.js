var indexSectionsWithContent =
{
  0: "abcdefghimnprstvxyz~",
  1: "acimnv",
  2: "fms",
  3: "abcdeghimnprstv~",
  4: "abfgrxyz",
  5: "mt",
  6: "mt",
  7: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

