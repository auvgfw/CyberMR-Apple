var searchData=
[
  ['g',['g',['../struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data.html#a130070e12e75d4519871d2d7e832c5ee',1,'MVGraphAPI::ColRGBAData']]]
];
