var searchData=
[
  ['r',['r',['../struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data.html#ae8203024655e47864dff9eb13681235e',1,'MVGraphAPI::ColRGBAData']]]
];
