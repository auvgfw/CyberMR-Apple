var searchData=
[
  ['depthmap_5ftexture_5fdata_5flayer',['DEPTHMAP_TEXTURE_DATA_LAYER',['../_simple_data_layers_guids_8h.html#a0d489d6395f7cb24d2b9dd7e22a25ec8',1,'MVGraphAPI::SimpleDataLayersGuids']]],
  ['dxt1_5ftexture_5fdata_5flayer',['DXT1_TEXTURE_DATA_LAYER',['../_simple_data_layers_guids_8h.html#afaf1121cadfd2aeadebdd7bcdfb29db3',1,'MVGraphAPI::SimpleDataLayersGuids']]],
  ['dxt5ycocg_5ftexture_5fdata_5flayer',['DXT5YCOCG_TEXTURE_DATA_LAYER',['../_simple_data_layers_guids_8h.html#a36dc7c51b7d21b2fe3be137b246ddba0',1,'MVGraphAPI::SimpleDataLayersGuids']]]
];
