var _simple_data_layers_guids_8h =
[
    [ "ASTC_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#abb3e243b260f3cd46c2f3618cbf0c35a", null ],
    [ "AUDIO_DATA_LAYER", "_simple_data_layers_guids_8h.html#afa8cbc4c8f6a4830089deba1da9ac5e3", null ],
    [ "BYTEARRAY_DATA_LAYER", "_simple_data_layers_guids_8h.html#a94e702db7980c0043e82cf9c6bd27e59", null ],
    [ "CAMERA_PARAMS_DATA_LAYER", "_simple_data_layers_guids_8h.html#ac21ad7e044a8822ef1f178b61bcb1bbb", null ],
    [ "DEPTHMAP_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#a0d489d6395f7cb24d2b9dd7e22a25ec8", null ],
    [ "DXT1_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#afaf1121cadfd2aeadebdd7bcdfb29db3", null ],
    [ "DXT5YCOCG_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#a36dc7c51b7d21b2fe3be137b246ddba0", null ],
    [ "ETC2_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#aebe7b1dfb0ad50afc8f047e6ee3dc4a9", null ],
    [ "IR_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#ae0422acd43396b54d5e707a088e11a7e", null ],
    [ "NVX_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#a59614a91e67c901e1bfd5ab45141f158", null ],
    [ "RGB_TEXTURE_DATA_LAYER", "_simple_data_layers_guids_8h.html#a4b445bcf3ef49281e4cf418463277213", null ],
    [ "SEGMENT_INFO_DATA_LAYER", "_simple_data_layers_guids_8h.html#a71326a06eed5b9e4638aaefac979f73b", null ],
    [ "TRANSFORM_DATA_LAYER", "_simple_data_layers_guids_8h.html#acaf7fbfcb04d2b31069e5f0ac2503abc", null ],
    [ "VERTEX_COLORS_DATA_LAYER", "_simple_data_layers_guids_8h.html#a07045c41c77e5699014b8a8c0f91131d", null ],
    [ "VERTEX_INDICES_DATA_LAYER", "_simple_data_layers_guids_8h.html#ac23b1047ec0a9464fd4f26812ef02159", null ],
    [ "VERTEX_NORMALS_DATA_LAYER", "_simple_data_layers_guids_8h.html#a0b85abb66c5b9135ae2a552c08c90f07", null ],
    [ "VERTEX_POSITIONS_DATA_LAYER", "_simple_data_layers_guids_8h.html#ae83b33e6660df1e1e94628cb59507adb", null ],
    [ "VERTEX_UVS_DATA_LAYER", "_simple_data_layers_guids_8h.html#a577415889cdff857f132691c8126992c", null ]
];