var hierarchy =
[
    [ "MVGraphAPI::ColRGBAData", "struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data.html", null ],
    [ "GraphNode", null, [
      [ "MVGraphAPI::AutoCompressorGraphNode", "class_m_v_graph_a_p_i_1_1_auto_compressor_graph_node.html", null ],
      [ "MVGraphAPI::AutoDecompressorGraphNode", "class_m_v_graph_a_p_i_1_1_auto_decompressor_graph_node.html", null ],
      [ "MVGraphAPI::InjectMemoryDataGraphNode", "class_m_v_graph_a_p_i_1_1_inject_memory_data_graph_node.html", null ]
    ] ],
    [ "NonAssignable", null, [
      [ "MVGraphAPI::MeshData", "class_m_v_graph_a_p_i_1_1_mesh_data.html", null ],
      [ "MVGraphAPI::MeshSplitter", "class_m_v_graph_a_p_i_1_1_mesh_splitter.html", null ],
      [ "MVGraphAPI::Mvx2FileAsyncReader", "class_m_v_graph_a_p_i_1_1_mvx2_file_async_reader.html", null ],
      [ "MVGraphAPI::Mvx2FileRandomAccessReader", "class_m_v_graph_a_p_i_1_1_mvx2_file_random_access_reader.html", null ],
      [ "MVGraphAPI::Mvx2FileSimpleDataInfo", "class_m_v_graph_a_p_i_1_1_mvx2_file_simple_data_info.html", null ],
      [ "MVGraphAPI::Mvx2FileSyncReader", "class_m_v_graph_a_p_i_1_1_mvx2_file_sync_reader.html", null ]
    ] ],
    [ "SingleFilterGraphNode", null, [
      [ "MVGraphAPI::InjectFileDataGraphNode", "class_m_v_graph_a_p_i_1_1_inject_file_data_graph_node.html", null ],
      [ "MVGraphAPI::Mvx2FileReaderGraphNode", "class_m_v_graph_a_p_i_1_1_mvx2_file_reader_graph_node.html", null ],
      [ "MVGraphAPI::Mvx2FileWriterGraphNode", "class_m_v_graph_a_p_i_1_1_mvx2_file_writer_graph_node.html", null ],
      [ "MVGraphAPI::NetworkReceiverGraphNode", "class_m_v_graph_a_p_i_1_1_network_receiver_graph_node.html", null ],
      [ "MVGraphAPI::NetworkTransmitterGraphNode", "class_m_v_graph_a_p_i_1_1_network_transmitter_graph_node.html", null ]
    ] ],
    [ "MVGraphAPI::Vec2Data", "struct_m_v_graph_a_p_i_1_1_vec2_data.html", null ],
    [ "MVGraphAPI::Vec3Data", "struct_m_v_graph_a_p_i_1_1_vec3_data.html", null ]
];