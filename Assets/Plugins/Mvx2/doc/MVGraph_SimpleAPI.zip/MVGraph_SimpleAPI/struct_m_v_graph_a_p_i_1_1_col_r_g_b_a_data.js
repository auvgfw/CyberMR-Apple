var struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data =
[
    [ "a", "struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data.html#a796ceb8f0f486fe903d5f59015abc267", null ],
    [ "b", "struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data.html#ac52ebd062db82bf4a907f3ec25f29ac4", null ],
    [ "g", "struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data.html#a130070e12e75d4519871d2d7e832c5ee", null ],
    [ "r", "struct_m_v_graph_a_p_i_1_1_col_r_g_b_a_data.html#ae8203024655e47864dff9eb13681235e", null ]
];