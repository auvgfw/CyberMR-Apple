var _frame_texture_extractor_8h =
[
    [ "TextureType", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37", [
      [ "TT_DEPTH", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37a39520357603ecfa1e71fbb6b5adb6286", null ],
      [ "TT_IR", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37a8a6e1780036701f022254921e5b9baa8", null ],
      [ "TT_RGB", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37aac9856673f77c74c436fd391f29050e6", null ],
      [ "TT_NVX", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37a0bc3202d7653f807d0f7c686b32479a5", null ],
      [ "TT_DXT5YCOCG", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37ac6aaf1f6bcd45c0ba3f4ec1a69159614", null ],
      [ "TT_DXT1", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37af331bdbadb0bd51d9bc9e4974c6be06c", null ],
      [ "TT_ETC2", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37a4987d49a8674184a5a34ac38872f23c7", null ],
      [ "TT_ASTC", "_frame_texture_extractor_8h.html#a7e7286b65eefd0cf6435d54890395e37ab751b89b988ea03c71e867582af27c01", null ]
    ] ],
    [ "CopyTextureData", "_frame_texture_extractor_8h.html#a37cc118cb5e25ff4be43c5fdc93b261e", null ],
    [ "GetTextureData", "_frame_texture_extractor_8h.html#aab229cd67c8bae224439a9a2d2274ec7", null ],
    [ "GetTextureDataSizeInBytes", "_frame_texture_extractor_8h.html#aa665bd37f7c876673302562b88ad7788", null ],
    [ "GetTextureResolution", "_frame_texture_extractor_8h.html#a41520618e8bf9a2d0a92a0afe0aaa83d", null ]
];