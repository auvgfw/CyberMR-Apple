var class_m_v_graph_a_p_i_1_1_frame =
[
    [ "Frame", "class_m_v_graph_a_p_i_1_1_frame.html#a2a5677a18a38a66c7f1bde1847842b50", null ],
    [ "ActivateStreamWithIndex", "class_m_v_graph_a_p_i_1_1_frame.html#a476eea9c152dd2e375f9eb529621378c", null ],
    [ "DestroyNativeObject", "class_m_v_graph_a_p_i_1_1_frame.html#a2be55c78fc1408088e597296bebfab7d", null ],
    [ "GetActiveStreamIndex", "class_m_v_graph_a_p_i_1_1_frame.html#a207dd2cf266d9d5ac4a8c661b3302af2", null ],
    [ "GetNumStreams", "class_m_v_graph_a_p_i_1_1_frame.html#abd482fe6fb7557f15a20d277cec6eab0", null ],
    [ "GetStreamAtomNr", "class_m_v_graph_a_p_i_1_1_frame.html#aefd1eac68ec209a9e4d0ea23c3bfab34", null ],
    [ "GetStreamAtomTimestamp", "class_m_v_graph_a_p_i_1_1_frame.html#a44b1505379708d5b94c9fddc0e9c0b7f", null ],
    [ "GetStreamId", "class_m_v_graph_a_p_i_1_1_frame.html#a4b21cf7c55fe5ed44ecdfe5d2cf9cd38", null ],
    [ "StreamContainsDataLayer", "class_m_v_graph_a_p_i_1_1_frame.html#ace3bf0d84d1a1c027ecb8ea5bc77ed5a", null ],
    [ "StreamContainsDataLayer", "class_m_v_graph_a_p_i_1_1_frame.html#a0bf53960a1426d7106c629aee88b3fe4", null ],
    [ "nativeFrameObject", "class_m_v_graph_a_p_i_1_1_frame.html#a10989bb7e7760e6959d44dbf1d383bc1", null ]
];