var class_m_v_graph_a_p_i_1_1_graph =
[
    [ "DestroyNativeObject", "class_m_v_graph_a_p_i_1_1_graph.html#ad02ee1cc4a22f7ce373773d3ae8df024", null ],
    [ "nativeGraphObject", "class_m_v_graph_a_p_i_1_1_graph.html#aa8f41fe87af982c717ba5401d4da56b4", null ]
];