var class_m_v_graph_a_p_i_1_1_frame_listener =
[
    [ "FrameListener", "class_m_v_graph_a_p_i_1_1_frame_listener.html#a8869e3f8c3bf1fd8799e94a1b80bd910", null ],
    [ "DestroyNativeObject", "class_m_v_graph_a_p_i_1_1_frame_listener.html#a3a505bdbdc24c756168795e96f974ff4", null ],
    [ "OnFrameProcessed", "class_m_v_graph_a_p_i_1_1_frame_listener.html#a19e9ade6bc968c0dfd59b4f6602b4fb1", null ],
    [ "nativeFrameListenerObject", "class_m_v_graph_a_p_i_1_1_frame_listener.html#a298a88dd7e5928535dd53217d09ff08d", null ]
];