var searchData=
[
  ['nativeframelistenerobject',['nativeFrameListenerObject',['../class_m_v_graph_a_p_i_1_1_frame_listener.html#a298a88dd7e5928535dd53217d09ff08d',1,'MVGraphAPI::FrameListener']]],
  ['nativeframeobject',['nativeFrameObject',['../class_m_v_graph_a_p_i_1_1_frame.html#a10989bb7e7760e6959d44dbf1d383bc1',1,'MVGraphAPI::Frame']]],
  ['nativeparametervaluechangedlistenerobject',['nativeParameterValueChangedListenerObject',['../class_m_v_graph_a_p_i_1_1_parameter_value_changed_listener.html#a2edaf5733cf6d3e6068cda438d41d0ca',1,'MVGraphAPI::ParameterValueChangedListener']]]
];
