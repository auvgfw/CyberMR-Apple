var searchData=
[
  ['delegatedframelistener',['DelegatedFrameListener',['../class_m_v_graph_a_p_i_1_1_delegated_frame_listener.html',1,'MVGraphAPI']]],
  ['delegatedparametervaluechangedlistener',['DelegatedParameterValueChangedListener',['../class_m_v_graph_a_p_i_1_1_delegated_parameter_value_changed_listener.html',1,'MVGraphAPI']]]
];
