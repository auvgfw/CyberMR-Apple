var searchData=
[
  ['loadplugin',['LoadPlugin',['../class_m_v_graph_a_p_i_1_1_plugins_loader.html#a8f25bc31350a479bebbdb047eec4ea71',1,'MVGraphAPI::PluginsLoader']]],
  ['loadpluginsinfolder',['LoadPluginsInFolder',['../class_m_v_graph_a_p_i_1_1_plugins_loader.html#a30488f20db0eb00c1d22fa61d07e1182',1,'MVGraphAPI::PluginsLoader']]]
];
