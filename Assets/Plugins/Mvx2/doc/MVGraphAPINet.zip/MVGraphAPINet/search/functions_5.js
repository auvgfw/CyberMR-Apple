var searchData=
[
  ['getactivestreamindex',['GetActiveStreamIndex',['../class_m_v_graph_a_p_i_1_1_frame.html#a207dd2cf266d9d5ac4a8c661b3302af2',1,'MVGraphAPI::Frame']]],
  ['getappexedirectory',['GetAppExeDirectory',['../class_m_v_graph_a_p_i_1_1_utils.html#accb73288c7218dcfbce746c39be81ddf',1,'MVGraphAPI::Utils']]],
  ['getappexefilepath',['GetAppExeFilePath',['../class_m_v_graph_a_p_i_1_1_utils.html#afc8426f0161cfad6cbc8124eafd441f3',1,'MVGraphAPI::Utils']]],
  ['getdroppedframescount',['GetDroppedFramesCount',['../class_m_v_graph_a_p_i_1_1_block_graph_node.html#aedb4c5788eb02a7cccaace8e3fd1af75',1,'MVGraphAPI::BlockGraphNode']]],
  ['getfps',['GetFPS',['../class_m_v_graph_a_p_i_1_1_source_info.html#a8250ca9a13a10fa4e18de558e3fbc0c0',1,'MVGraphAPI::SourceInfo']]],
  ['getnumframes',['GetNumFrames',['../class_m_v_graph_a_p_i_1_1_source_info.html#a3a329af1ae08d3b0fc3b762b39f0b887',1,'MVGraphAPI::SourceInfo']]],
  ['getnumstreams',['GetNumStreams',['../class_m_v_graph_a_p_i_1_1_frame.html#abd482fe6fb7557f15a20d277cec6eab0',1,'MVGraphAPI::Frame']]],
  ['getrecentprocessedframe',['GetRecentProcessedFrame',['../class_m_v_graph_a_p_i_1_1_frame_access_graph_node.html#a684cc38dd29dc9dfba64df329c17091d',1,'MVGraphAPI::FrameAccessGraphNode']]],
  ['getsourceinfo',['GetSourceInfo',['../class_m_v_graph_a_p_i_1_1_graph_runner.html#ac9e22c930a64f2ba43a951f241d32c57',1,'MVGraphAPI::GraphRunner']]],
  ['getstreamatomnr',['GetStreamAtomNr',['../class_m_v_graph_a_p_i_1_1_frame.html#aefd1eac68ec209a9e4d0ea23c3bfab34',1,'MVGraphAPI::Frame']]],
  ['getstreamatomtimestamp',['GetStreamAtomTimestamp',['../class_m_v_graph_a_p_i_1_1_frame.html#a44b1505379708d5b94c9fddc0e9c0b7f',1,'MVGraphAPI::Frame']]],
  ['getstreamid',['GetStreamId',['../class_m_v_graph_a_p_i_1_1_frame.html#a4b21cf7c55fe5ed44ecdfe5d2cf9cd38',1,'MVGraphAPI::Frame']]],
  ['graphbuilder',['GraphBuilder',['../class_m_v_graph_a_p_i_1_1_graph_builder.html#a2abdbcd164af15ab1532836140cd29c9',1,'MVGraphAPI::GraphBuilder']]],
  ['graphnode',['GraphNode',['../class_m_v_graph_a_p_i_1_1_graph_node.html#a5d67d961a42220c4e387e227d8116376',1,'MVGraphAPI::GraphNode']]],
  ['graphrunner',['GraphRunner',['../class_m_v_graph_a_p_i_1_1_graph_runner.html#af5a0310785571a14168da43245396dbf',1,'MVGraphAPI::GraphRunner']]]
];
