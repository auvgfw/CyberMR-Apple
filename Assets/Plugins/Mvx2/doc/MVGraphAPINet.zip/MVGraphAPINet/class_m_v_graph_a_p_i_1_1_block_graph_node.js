var class_m_v_graph_a_p_i_1_1_block_graph_node =
[
    [ "FullBehaviour", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a18b2bd77713245c1e3c67b03fbfab4ed", [
      [ "FB_DROP_FRAMES", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a18b2bd77713245c1e3c67b03fbfab4edad20c9800480e9120387a7147d15232f4", null ],
      [ "FB_BLOCK_FRAMES", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a18b2bd77713245c1e3c67b03fbfab4edaa10299ee1abea396f6bdaf13a908ad12", null ]
    ] ],
    [ "BlockGraphNode", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#a86479bebeb22e59cb1ad066ee3afe1af", null ],
    [ "GetDroppedFramesCount", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#aedb4c5788eb02a7cccaace8e3fd1af75", null ],
    [ "ResetDroppedFramesCounter", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#af70c6f48680b6e63b2477b57600bf0e4", null ],
    [ "SetFullBehaviour", "class_m_v_graph_a_p_i_1_1_block_graph_node.html#ae36190e23a0e0e17549285f1332cd5a2", null ]
];