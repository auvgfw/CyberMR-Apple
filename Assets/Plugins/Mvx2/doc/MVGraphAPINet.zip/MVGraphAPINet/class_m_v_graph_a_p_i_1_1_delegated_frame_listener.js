var class_m_v_graph_a_p_i_1_1_delegated_frame_listener =
[
    [ "DelegatedFrameListener", "class_m_v_graph_a_p_i_1_1_delegated_frame_listener.html#a7e7777acbb8729254a54623dcab5adb0", null ],
    [ "OnFrameProcessed", "class_m_v_graph_a_p_i_1_1_delegated_frame_listener.html#a15535d58bc086e4eec9685fb4d8dd9f2", null ],
    [ "OnFrameProcessedDelegate", "class_m_v_graph_a_p_i_1_1_delegated_frame_listener.html#a79f0ed5524900207709d1c9b199a198c", null ]
];