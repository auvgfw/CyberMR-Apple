var class_m_v_graph_a_p_i_1_1_frame_access_graph_node =
[
    [ "FrameAccessGraphNode", "class_m_v_graph_a_p_i_1_1_frame_access_graph_node.html#a574fc1fd522c0ce89e973de9193916e4", null ],
    [ "GetRecentProcessedFrame", "class_m_v_graph_a_p_i_1_1_frame_access_graph_node.html#a684cc38dd29dc9dfba64df329c17091d", null ]
];