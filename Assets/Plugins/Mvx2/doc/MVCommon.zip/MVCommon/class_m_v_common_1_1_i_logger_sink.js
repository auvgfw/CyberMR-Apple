var class_m_v_common_1_1_i_logger_sink =
[
    [ "ILoggerSink", "class_m_v_common_1_1_i_logger_sink.html#a82b5449ad5e2b2aafe60a19dbcd25469", null ],
    [ "~ILoggerSink", "class_m_v_common_1_1_i_logger_sink.html#ad46257c81ed04c3af3e76c008f3fa658", null ],
    [ "AddLogEntry", "class_m_v_common_1_1_i_logger_sink.html#ad93b3834fbb80edba5b9ebf7deff7d49", null ],
    [ "GetLogLevel", "class_m_v_common_1_1_i_logger_sink.html#a906789dc3ec4fc75c1f34dfddb6496f8", null ],
    [ "HandleLogEntry", "class_m_v_common_1_1_i_logger_sink.html#a410c4e81d4efeb673b27c12a636bf0db", null ],
    [ "LogLevelToString", "class_m_v_common_1_1_i_logger_sink.html#a6fdbc3f1f22a42ed8cae72cd5cfa11b6", null ],
    [ "SetLogLevel", "class_m_v_common_1_1_i_logger_sink.html#a7ef7b3d5f4728f4a83053c9413eda0a4", null ],
    [ "TimestampToString", "class_m_v_common_1_1_i_logger_sink.html#a94905ed9c1a1b7bb138f67ea83c66790", null ]
];