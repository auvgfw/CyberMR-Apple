var _guid_generator_8h =
[
    [ "GenerateGuid", "_guid_generator_8h.html#a21c2c8d74ce66ea24b1f997c391b646f", null ],
    [ "GenerateGuid", "_guid_generator_8h.html#a9f7df31345285aaa6d3ea273955234be", null ]
];