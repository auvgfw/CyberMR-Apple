var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvwxyz~",
  1: "abcfghilmprsvw",
  2: "bgls",
  3: "abcdefghilmnoprstuvw~",
  4: "cdfhrstwxyz",
  5: "t",
  6: "l",
  7: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator"
};

