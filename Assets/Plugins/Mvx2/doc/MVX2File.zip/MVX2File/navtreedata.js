var NAVTREE =
[
  [ "MVX2File", "index.html", [
    [ "Mantis Vision: MVX2File", "index.html", null ]
  ] ]
];

var NAVTREEINDEX =
[
"index.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';