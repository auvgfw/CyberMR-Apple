var hierarchy =
[
    [ "Attribute", null, [
      [ "MonoPInvokeCallbackAttribute", "class_mono_p_invoke_callback_attribute.html", null ]
    ] ],
    [ "MVCommon.GuidGenerator", "class_m_v_common_1_1_guid_generator.html", null ],
    [ "MVCommon.HostSettings", "class_m_v_common_1_1_host_settings.html", null ],
    [ "IDisposable", null, [
      [ "MVCommon.NativeObjectHolder", "class_m_v_common_1_1_native_object_holder.html", [
        [ "MVCommon.BlockingCounter", "class_m_v_common_1_1_blocking_counter.html", null ],
        [ "MVCommon.ByteArray", "class_m_v_common_1_1_byte_array.html", null ],
        [ "MVCommon.CameraParams", "class_m_v_common_1_1_camera_params.html", null ],
        [ "MVCommon.Color", "class_m_v_common_1_1_color.html", null ],
        [ "MVCommon.Guid", "class_m_v_common_1_1_guid.html", null ],
        [ "MVCommon.GuidAliasDatabase", "class_m_v_common_1_1_guid_alias_database.html", null ],
        [ "MVCommon.ILoggerSink", "class_m_v_common_1_1_i_logger_sink.html", [
          [ "MVCommon.AndroidSystemLoggerSink", "class_m_v_common_1_1_android_system_logger_sink.html", null ],
          [ "MVCommon.AppleSystemLoggerSink", "class_m_v_common_1_1_apple_system_logger_sink.html", null ],
          [ "MVCommon.FileLoggerSink", "class_m_v_common_1_1_file_logger_sink.html", null ],
          [ "MVCommon.NetLoggerSink", "class_m_v_common_1_1_net_logger_sink.html", null ],
          [ "MVCommon.RedirectingLoggerSink", "class_m_v_common_1_1_redirecting_logger_sink.html", null ],
          [ "MVCommon.StdOutLoggerSink", "class_m_v_common_1_1_std_out_logger_sink.html", null ]
        ] ],
        [ "MVCommon.LogEntry", "class_m_v_common_1_1_log_entry.html", null ],
        [ "MVCommon.Logger", "class_m_v_common_1_1_logger.html", null ],
        [ "MVCommon.Matrix4x4d", "class_m_v_common_1_1_matrix4x4d.html", null ],
        [ "MVCommon.Matrix4x4f", "class_m_v_common_1_1_matrix4x4f.html", null ],
        [ "MVCommon.String", "class_m_v_common_1_1_string.html", null ],
        [ "MVCommon.Vector2d", "class_m_v_common_1_1_vector2d.html", null ],
        [ "MVCommon.Vector2f", "class_m_v_common_1_1_vector2f.html", null ],
        [ "MVCommon.Vector3d", "class_m_v_common_1_1_vector3d.html", null ],
        [ "MVCommon.Vector3f", "class_m_v_common_1_1_vector3f.html", null ],
        [ "MVCommon.Vector4d", "class_m_v_common_1_1_vector4d.html", null ],
        [ "MVCommon.Vector4f", "class_m_v_common_1_1_vector4f.html", null ],
        [ "MVCommon.Versord", "class_m_v_common_1_1_versord.html", null ],
        [ "MVCommon.Versorf", "class_m_v_common_1_1_versorf.html", null ]
      ] ],
      [ "MVCommon.SharedRef< T >", "class_m_v_common_1_1_shared_ref.html", null ]
    ] ],
    [ "IEnumerable< KeyValuePair< Guid, String >>", null, [
      [ "MVCommon.GuidAliasDatabase", "class_m_v_common_1_1_guid_alias_database.html", null ]
    ] ],
    [ "IEnumerator< KeyValuePair< Guid, String >>", null, [
      [ "MVCommon.GuidAliasDatabaseEnumerator", "class_m_v_common_1_1_guid_alias_database_enumerator.html", null ]
    ] ],
    [ "IEquatable", null, [
      [ "MVCommon.ByteArray", "class_m_v_common_1_1_byte_array.html", null ],
      [ "MVCommon.CameraParams", "class_m_v_common_1_1_camera_params.html", null ],
      [ "MVCommon.Color", "class_m_v_common_1_1_color.html", null ],
      [ "MVCommon.Guid", "class_m_v_common_1_1_guid.html", null ],
      [ "MVCommon.GuidAliasDatabase", "class_m_v_common_1_1_guid_alias_database.html", null ],
      [ "MVCommon.ILoggerSink", "class_m_v_common_1_1_i_logger_sink.html", null ],
      [ "MVCommon.Logger", "class_m_v_common_1_1_logger.html", null ],
      [ "MVCommon.Matrix4x4d", "class_m_v_common_1_1_matrix4x4d.html", null ],
      [ "MVCommon.Matrix4x4f", "class_m_v_common_1_1_matrix4x4f.html", null ],
      [ "MVCommon.String", "class_m_v_common_1_1_string.html", null ],
      [ "MVCommon.Vector2d", "class_m_v_common_1_1_vector2d.html", null ],
      [ "MVCommon.Vector2f", "class_m_v_common_1_1_vector2f.html", null ],
      [ "MVCommon.Vector3d", "class_m_v_common_1_1_vector3d.html", null ],
      [ "MVCommon.Vector3f", "class_m_v_common_1_1_vector3f.html", null ],
      [ "MVCommon.Vector4d", "class_m_v_common_1_1_vector4d.html", null ],
      [ "MVCommon.Vector4f", "class_m_v_common_1_1_vector4f.html", null ],
      [ "MVCommon.Versord", "class_m_v_common_1_1_versord.html", null ],
      [ "MVCommon.Versorf", "class_m_v_common_1_1_versorf.html", null ]
    ] ],
    [ "MVCommon.LoggerRegistry", "class_m_v_common_1_1_logger_registry.html", null ],
    [ "MVCommon.Math", "class_m_v_common_1_1_math.html", null ],
    [ "MVCommon.MVCommonNetConstants", "class_m_v_common_1_1_m_v_common_net_constants.html", null ]
];