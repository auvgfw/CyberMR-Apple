var searchData=
[
  ['androidsystemloggersink',['AndroidSystemLoggerSink',['../class_m_v_common_1_1_android_system_logger_sink.html',1,'MVCommon']]],
  ['applesystemloggersink',['AppleSystemLoggerSink',['../class_m_v_common_1_1_apple_system_logger_sink.html',1,'MVCommon']]]
];
