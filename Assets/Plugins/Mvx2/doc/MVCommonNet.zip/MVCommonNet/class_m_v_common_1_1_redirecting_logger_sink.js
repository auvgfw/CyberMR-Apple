var class_m_v_common_1_1_redirecting_logger_sink =
[
    [ "RedirectingLoggerSink", "class_m_v_common_1_1_redirecting_logger_sink.html#a6f9e461c6a0938d3f64492761bfc60e6", null ]
];